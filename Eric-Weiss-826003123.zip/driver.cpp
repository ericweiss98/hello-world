#include <iostream> 
#include <iterator> 
#include <map>
#include <vector>
#include <bitset>
#include <string>
#include <fstream> 

using namespace std; 

//work with A instruction
string A_instruction(string line, map<string, int> &ST, map<int, bool> &taken) {
	
	string noA;
	//find string without extra spaces on end
	for (int i = 1; i <line.size(); ++i) {
		if (line.at(i) >= '!' && line.at(i) <= 'z') {
			noA += line.at(i);
		}
	}

	int val = 0;
	
	//set val to the string if string is digit
	if (isdigit(noA.at(0))) {
		val = atoi(noA.c_str());
	}
	else {
		map<string,int>::iterator itr = ST.find(noA);
		//add the next open value to the unfound variable
		if (itr == ST.end()) {
			int i = 16;
			while (i < 100) {
				map<int,bool>::const_iterator itr2 = taken.find(i);
				if (itr2 == taken.end()) {
					ST.insert(pair<string, int>(noA, i));
					taken.insert(pair<int, bool>(i, true));
					val = i;
					break;
				}
				++i;
			}
		}
		//set variable to found ST value
		else {
			val = itr->second;
		}
	}
	
	//turn the value into a 16 bit binary string
	string A = bitset<16>(val).to_string();
	
	return A;
}

//work with comp bits
string Comp(string line) {
	
	string afterEQ = "";
	//starts at 0
	string comp = "101010";
	bool eq = false;
	
	//get the desired part
	for (int i = 0; i <line.size(); ++i) {
		if (line.at(i) == '=') {
			eq = true;
			afterEQ = line.substr(i+1);
			break;
		}
		if (line.at(i) == ';') {
			if (i == 1) {
				afterEQ = line.at(0);
				eq = true;
			}
			break;
		}
	}
		
	string a = "0";
	//find the a
	for (int i = 0; i < afterEQ.size(); ++i) {
		if (afterEQ.at(i) == 'M') {
			a = "1";
			break;
		}
		else if (afterEQ.at(i) == ';' || afterEQ.at(i) == '/') {
			break;
		}
	}
	
	//if comp is needed
	if (eq == true) {
		if (afterEQ.at(0) == '0') {
			//do nothing
		}
		//checks for 1
		else if (afterEQ.at(0) == '1') {
			comp = "111111";
		}
		//check for -1/-D/-A/-M
		else if (afterEQ.size() > 1 && afterEQ.at(0) == '-') {
			if (afterEQ.at(1) == '1') {
				comp = "111010";
			}
			else if (afterEQ.at(1) == 'D') {
				comp = "001111";
			}
			else if (afterEQ.at(1) == 'M' || afterEQ.at(1) == 'A') {
				comp = "110011";
			}
		}
		//check for !D/!A/!M
		else if (afterEQ.at(0) == '!') {
			if (afterEQ.at(1) == 'D') {
				comp = "001101";
			}
			else {
				comp = "110001";
			}
		}
		//check for anything starting with D
		else if (afterEQ.at(0) == 'D') {
			if (afterEQ.size() > 1 && afterEQ.at(1) == '+') {
				if (afterEQ.at(2) == '1') {
					comp = "011111";
				}
				else if (afterEQ.at(2) == 'A' || afterEQ.at(2) == 'M') {
					comp = "000010";
				}
			}
			else if (afterEQ.size() > 1 && afterEQ.at(1) == '-') {
				if (afterEQ.at(2) == '1') {
					comp = "001110";
				}
				else if (afterEQ.at(2) == 'A' || afterEQ.at(2) == 'M') {
					comp = "010011";
				}
			}
			else if (afterEQ.size() > 1 && afterEQ.at(1) == '&') {
				if (afterEQ.at(2) == 'A' || afterEQ.at(2) == 'M') {
					comp= "000000";
				}
			}
			else if (afterEQ.size() > 1 && afterEQ.at(1) == '|') {
				if (afterEQ.at(2) == 'A' || afterEQ.at(2) == 'M') {
					comp= "010101";
				}
			}
			//just D
			else {
				comp = "001100";
			}
		}
		//check for anything starting with A/M
		else {
			if (afterEQ.size() > 1 && afterEQ.at(1) == '+') {
				if (afterEQ.at(2) == '1') {
					comp = "110111";
				}
				else if (afterEQ.at(2) == 'D') {
					comp = "000010";
				}
			}
			else if (afterEQ.size() > 1 && afterEQ.at(1) == '-') {
				if (afterEQ.at(2) == '1') {
					comp = "110010";
				}
				else if (afterEQ.at(2) == 'D') {
					comp = "000111";
				}
			}
			else if (afterEQ.size() > 1 && afterEQ.at(1) == '&') {
				if (afterEQ.at(2) == 'D') {
					comp= "000000";
				}
			}
			else if (afterEQ.size() > 1 && afterEQ.at(1) == '|') {
				if (afterEQ.at(2) == 'D') {
					comp= "010101";
				}
			}
			//just A/M
			else {
				comp = "110000";
			}
		}
	}
		
	return a + comp;
}

//work with destination
string dest(string line) {
	string d1 = "0";
	string d2 = "0";
	string d3 = "0";
	bool eq = false;
	//find if there is a destination
	for (int i = 0; i < line.size(); ++i) {
		if (line.at(i) == ';') {
			break;
		}
		//sets a destination
		if (line.at(i) == '=') {
			eq = true;
		}
	}
	
	//finds what is needed if there is an =
	if (eq == true) {
		for (int i = 0; i <line.size(); ++i) {
			if (line.at(i) == 'M') {
				d3 = "1";
			}
			else if (line.at(i) == 'D') {
				d2 = "1";
			}
			else if (line.at(i) == 'A') {
				d1 = "1";
			}
			else if (line.at(i) == '=' || line.at(i) == ';') {
				break;
			}
		}
	}
	
	return d1 + d2 + d3;
}

//find jump condition
string jmp(string line) {
	string j1 = "0";
	string j2 = "0";
	string j3 = "0";
	
	for (int i = 0; i < line.size(); ++i) {
		//check all the values if there is a ;
		if (line.at(i) == ';') {
			if (line.at(i+2) == 'M' || line.at(i+2) == 'L' || line.at(i+2) == 'N') {
				j1 = "1";
			}
			if (line.at(i+2) == 'M' || (line.at(i+3) == 'E' && line.at(i+2) != 'N') || line.at(i+3) == 'Q') {
				j2 = "1";
			}
			if (line.at(i+2) == 'M' || line.at(i+2) == 'G' || line.at(i+2) == 'N') {
				j3 = "1";
			}
			break;
		}
	}
	return j1 + j2 + j3;
}

//first pass
map<string, int> Pass1(string filename, map<int,bool> &taken) {
	
	//make map with all reserved variables
	map<string, int> ST;
	ST.insert(pair<string, int>("SP", 0));
	ST.insert(pair<string, int>("LCL", 1));
	ST.insert(pair<string, int>("ARG", 2));
	ST.insert(pair<string, int>("THIS", 3));
	ST.insert(pair<string, int>("THAT", 4));
	ST.insert(pair<string, int>("R0", 0));
	ST.insert(pair<string, int>("R1", 1));
	ST.insert(pair<string, int>("R2", 2));
	ST.insert(pair<string, int>("R3", 3));
	ST.insert(pair<string, int>("R4", 4));
	ST.insert(pair<string, int>("R5", 5));
	ST.insert(pair<string, int>("R6", 6));
	ST.insert(pair<string, int>("R7", 7));
	ST.insert(pair<string, int>("R8", 8));
	ST.insert(pair<string, int>("R9", 9));
	ST.insert(pair<string, int>("R10", 10));
	ST.insert(pair<string, int>("R11", 11));
	ST.insert(pair<string, int>("R12", 12));
	ST.insert(pair<string, int>("R13", 13));
	ST.insert(pair<string, int>("R14", 14));
	ST.insert(pair<string, int>("R15", 15));
	ST.insert(pair<string, int>("SCREEN", 16384));
	ST.insert(pair<string, int>("KBD", 24576));
	
	for (int i = 0; i < 16; ++i) {
		taken.insert(pair<int, bool>(i, true));
	}
	
	int lineNum = 0;
	string line;
	string var = "";
	
	//read file
	ifstream inFs;
	
	inFs.open(filename);
	
	if(!inFs.is_open()) {
		cout << "Error: Unable to open " << filename << endl;
	}
	else {
		while(!inFs.eof()) {
			//create entries in ST
			getline(inFs, line);
			for (int i = 0; i < line.size(); ++i) {
				if (line.at(i) == '/' || line.at(i) == '(') {
					break;
				}
				//doesn't add line if empty line
				else if (line.at(i) >= '!' && line.at(i) <= 'z' && line.at(i)) {
					++lineNum;
					break;
				}
			}
			//finds variable to be inputted
			if (line.size() != 0 && line.at(0) == '(') {
				for (int i = 1; i < line.size()-1 && line.at(i) != ')'; ++i) {
					var += line.at(i);
				}
				ST.insert(pair<string, int>(var, lineNum));
				taken.insert(pair<int, bool>(lineNum, true));
			}
			var = "";
		}
	}

	return ST;
}

//2nd pass
vector<string> Pass2(string filename, map<string, int> &ST, map<int, bool> &taken) {
	
	vector<string> instructions;
	string currInstr = "";
	string line = "";
	
	int lineNum = 0;
	
	//read file
	ifstream inFs;
	
	inFs.open(filename);
	
	if(!inFs.is_open()) {
		cout << "Error: Unable to open " << filename << endl;
	}
	else {
		while(!inFs.eof()) {
			//create entries in ST
			getline(inFs, line);
			++lineNum;

			//ignore if comment or blank
			if (line.size() != 0 && line.at(0) != '(' && line.at(0) != '/') {
				if (line.size() > 1 && line.at(1) != '/') {
					//get rid of tabs
					while(line.at(0) != '@' && line.at(0) != '1' && line.at(0) != '-'
					&& line.at(0) != 'D' && line.at(0) != 'M' && line.at(0) != 'A'
					&& line.at(0) != '0' && line.at(0) != '!') {
						line = line.substr(1);
					}
					//Check A instruction
					if (line.at(0) == '@') {
						currInstr = A_instruction(line, ST, taken);
					}
					//C-instruction
					else {
						currInstr = "111";
						currInstr += Comp(line);
						currInstr += dest(line);
						currInstr += jmp(line);
					}
					instructions.push_back(currInstr);
					currInstr = "";
				}
			}
		}
	}
	return instructions;
}


int main(int argc, char** argv) {

	string filename = argv[1];
	
	map<int, bool> taken;
	map<string, int> ST = Pass1(filename, taken);
	
	
	vector<string> instructions = Pass2(filename, ST, taken);
		
	//remove the asm
	filename.pop_back();
	filename.pop_back();
	filename.pop_back();
	
	string fileOutName = filename + "hack";
	
	//output
	ofstream oFs;
		
	oFs.open(fileOutName);
	for (int i = 0; i < instructions.size(); ++i) {
		oFs << instructions.at(i) << endl;
	}
	
	return 0;	

}